import numpy as np
from scipy import io
import os
from src.models.matchSVT import matchSVT
import torch


def make_dir(path):
    if not os.path.exists(path):
        os.makedirs(path)


def pre_processing(mat):
    data = np.array(mat)
    size = data.shape[0]
    k = 0
    b = 2

    for i in range(size):
        for j in range(size):
            if data[i][j] == 100:
                data[i][j] = k
            else:
                data[i][j] *= b

    for i in range(size):
        for j in range(size):
            if i == j:
                data[i][j] = 0
            elif data[i][j] == 0:
                data[i][j] += 0.1

    return data


def SVT(mat, number_list, this_threshold, this_alpha, this_lambda, pre_process=True):
    if pre_process:
        mat = torch.from_numpy(pre_processing(mat))
    number_of_person = [0]
    for i in range(len(number_list)):
        number_of_person.append(sum(number_list[:i + 1]))

    result = matchSVT(mat, number_of_person, alpha=this_alpha, _lambda=this_lambda, threshold=this_threshold,
                      dual_stochastic_SVT=True)

    return result


def match():
    threshold_list = [0.5, 0.3, 0.7]
    alpha_list = [0.1, 0.3, 0.5, 0.7]
    _lambda_list = [25, 50, 100]

    for this_threshold in threshold_list:
        for this_alpha in alpha_list:
            for this_lambda in _lambda_list:
                temp = 'threshold=%.1f,alpha=%.1f,lambda=%3d' % (
                    this_threshold, this_alpha, this_lambda)
                all_mat_dict = sorted(os.listdir(data_path))
                for mat_dict in all_mat_dict:
                    mat_dict_path = data_path + '/' + mat_dict

                    all_mat_name = sorted(os.listdir(mat_dict_path))
                    for mat_name in all_mat_name:
                        mat_path = mat_dict_path + '/' + mat_name

                        # read mat
                        mat = io.loadmat(mat_path)
                        cost_mat = np.array(mat.get('Net_Cost_Mat'))
                        cost_mat = torch.from_numpy(cost_mat)
                        number_person = np.array(mat.get('number_person'))
                        number_person = number_person.reshape((-1))

                        # SVN
                        SVN_result = SVT(cost_mat, number_person, this_threshold, this_alpha, this_lambda,
                                         pre_process=True)

                        # save result

                        out_path = save_path + '/' + temp + '/' + mat_dict
                        make_dir(out_path)
                        print(out_path)
                        result = {
                            'SVN_result': SVN_result,
                        }
                        io.savemat(out_path + '/' + mat_name, result)

                os.rename(save_path + '/' + temp, save_path + '/' + temp + '_done')


if __name__ == '__main__':
    data_path = "/home/yanhaomin/project/others/clustering_synthetic_matrix/weight_mat/Weight_mat_new_gen_2.0/"
    save_path = "/home/yanhaomin/project/others/clustering_synthetic_matrix/out/parameter_adjustment/"

    match()
