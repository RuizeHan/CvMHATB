import numpy as np
import itertools

method_list = ['GT_matrix', 'mvpose_predict']
filename = [0, 0, 0]
temp = [0, 0, 0]
match_num_dhn = 0
gt_num =  0
pred_num = 0

for method_id, method_i in enumerate(method_list):
    filename[method_id] = "/home/yun2020/PyCharm/mvpose/" + "test_syn" + "_" + method_i + ".npy"
    temp[method_id] = np.load(filename[method_id], allow_pickle=True)

for frame_i in range((temp[0].shape)[0]):
    match_num_dhn += np.sum((temp[1])[frame_i] * (temp[0])[frame_i])
    gt_num += np.sum((temp[0])[frame_i])
    pred_num += np.sum((temp[1])[frame_i])

print('mvpose')
print('match_num_dhn:',match_num_dhn)
print('pred_num:',pred_num)
print('gt_num:',gt_num)

print(match_num_dhn / pred_num)
print(match_num_dhn / gt_num)
print(2 * match_num_dhn / (pred_num + gt_num))