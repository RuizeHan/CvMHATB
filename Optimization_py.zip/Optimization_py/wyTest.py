from src.models.matchSVT import matchSVT
import os
import torch
import numpy as np
from scipy.io import savemat

#得到[GoPro1,GoPro3,GoPro4,GoPro5]
def get_filenum(path):
    filenum = []
    filelist = os.listdir(path)
    for i in filelist:
        filenum.append(i)
    return filenum
#得到GoPro1/GoPro3/GoPro4/GoPro5下文件的前缀
def get_startswith(filepath):
    list_startswith = []
    Txtfilelist = os.listdir(filepath)
    for i in range(len(Txtfilelist)):
        s = Txtfilelist[i].split('_')[0]
        list_startswith.append(s)
    list_startswith = list(set(list_startswith))
    return list_startswith

def copyfile(list_startswith,filenum,oldpath,newpath):
    for i in range(len(list_startswith)):
        for j in range(len(filenum)):
            rootdir = os.path.join(path,filenum[j])
            list = os.listdir(rootdir)
            for k in range(len(list)):
                os.rename(os.path.join(os.path.join(oldpath,filenum[j]),list[k]), os.path.join(newpath,''.join(filenum[j]) + '_' + list[k]))

def get_one_path(list_startswith,newpath):
    path_list_v2 = []
    list = os.listdir(newpath)
    for i in range(len(list_startswith)):
        path_list_mid = []
        for k in range(len(list)):
            if list[k].split('/')[-1].split('_')[1] == list_startswith[i]:
                path_list_mid.append(list[k])
        path_list_mid.sort()
        path_list_v2.append(path_list_mid)
    return path_list_v2

def get_data(newpath,all_file):
    dist_matrix = []
    dimGroup = []
    GT = []
    for i in range(len(all_file)):
        features = []
        number_of_person = []
        c1, c2, c3, c4 = 0, 0, 0, 0
        labels = torch.zeros(len(all_file[i]))
        for f in range(len(all_file[i])):
            fx = all_file[i][f]
            labels[f] = float(fx.split('.')[0].split('_')[-1])

            if fx.split('_')[0] == 'GoPro1':
                c1 += 1
            if fx.split('_')[0] == 'GoPro3':
                c2 += 1
            if fx.split('_')[0] == 'GoPro4':
                c3 += 1
            if fx.split('_')[0] == 'GoPro5':
                c4 += 1

            # ##### norm
            feature_file = np.loadtxt(os.path.join(newpath,fx))
            #feature_file = (feature_file - np.mean(feature_file)) / np.std(feature_file)
            features.append(feature_file)

        number_of_person.append(0)
        number_of_person.append(c1)
        number_of_person.append(c1 + c2)
        number_of_person.append(c1 + c2 + c3)
        number_of_person.append(c1 + c2 + c3 + c4)

        # 欧式距离
        features = np.array(features)
        features = torch.tensor(features)
        dist = torch.norm(features.unsqueeze(0) - features.unsqueeze(1), p=2, dim=2)
        dist = torch.sigmoid(dist)
        # dist = dist.numpy()

        GT_matrix = (labels.unsqueeze(0) == labels.unsqueeze(1)).float()
        GT_matrix = GT_matrix.numpy()

        GT.append(GT_matrix)
        dimGroup.append(number_of_person)
        dist_matrix.append(dist)

    return dist_matrix, dimGroup, GT


if __name__ == '__main__':

    #test数据feature的路径：dataset/wydata/matching/interaction/test_features/
    path = '/dataset/wydata/matching/interaction/test_features/'
    filepath = '/dataset/wydata/matching/interaction/test_features/GoPro1/'
    newpath = '/dataset/wydata/matching/interaction/wy1012_test_features/'
    list_startswith = get_startswith(filepath)
    filenum = get_filenum(path)
    all_file = get_one_path(list_startswith,newpath)
    W, dimGroup, GT = get_data(newpath,all_file)
    print(type(W))
    print(type(GT))
    print(type(W[0]))
    print(type(GT[0]))

    #单独存储dist，不需要预测，先注释
    match_mat = []
    for i in range(len(W)):
        print(i)
        match_mat.append(matchSVT(W[i], dimGroup[i], alpha=0.5, _lambda=50,
                             dual_stochastic_SVT=True))

    # test_W = np.zeros((7,7))
    # test_W = torch.tensor(test_W)
    # test_dimGroup = [0,2,4,7]
    # test_dimGroup = torch.tensor(test_dimGroup)
    # match_mat = matchSVT(test_W, test_dimGroup, alpha=0.5, _lambda=50,
    #                      dual_stochastic_SVT=False)
    # print(match_mat)
    # print(GT)
    np.save("/home/yun2020/PyCharm/mvpose/test_mvpose_predict.npy", match_mat)
    np.save("/home/yun2020/PyCharm/mvpose/test_GT_matrix.npy", GT)
    # savemat("/home/yun2020/PyCharm/mvpose/real_npy/test_GT_matrix.mat", {'GT': GT})
    # savemat("/home/yun2020/PyCharm/mvpose/real_npy/affi_matrix.mat",{'W': W})