import numpy as np
from sklearn.cluster import SpectralClustering
from scipy import io
import os
from src.models.matchSVT import matchSVT
import torch
import itertools
import time


def make_dir(path):
    if not os.path.exists(path):
        os.makedirs(path)


def create_P_matrix(pred):
    people_num = max(pred) + 1
    bbox_num = len(pred)
    matrix_temp = np.identity(bbox_num)
    for i in range(people_num):
        temp = []
        for j in range(bbox_num):
            if pred[j] == i:
                temp.append(j)
        cc = list(itertools.combinations(temp, 2))
        for (p, q) in cc:
            matrix_temp[p][q] = 1
            matrix_temp[q][p] = 1

    return matrix_temp


def pre_processing(mat):
    data = np.array(mat)
    size = data.shape[0]
    k = 0
    b = 1

    # for i in range(size):
    #     for j in range(size):
    #         if data[i][j] == 100:
    #             data[i][j] = k
    #         else:
    #             data[i][j] *= b

    for i in range(size):
        for j in range(size):
            if i == j:
                data[i][j] = 1
            elif data[i][j] == 0:
                data[i][j] += 0.1

    return data

def add_dm_weight(mat, weight):
    data = np.array(mat)
    size = data.shape[0]

    for i in range(size):
        for j in range(size):
            if data[i][j] == -1:
                data[i][j] = weight

    return data


def clustering(mat, number, pre_process=True):
    if pre_process:
        mat = pre_processing(mat)
    pred_y = SpectralClustering(n_clusters=number, random_state=1, affinity='precomputed').fit_predict(mat)
    matrix_P = create_P_matrix(pred_y)

    for i in range(len(matrix_P)):
        for j in range(len(matrix_P)):
            if i == j:
                matrix_P[i][j] = 1

    return matrix_P


# def SVT(mat, number_list, pre_process=True):
#     if pre_process:
#         mat = torch.from_numpy(pre_processing(mat))
#     number_of_person = [0]
#     for i in range(len(number_list)):
#         number_of_person.append(sum(number_list[:i + 1]))
#
#     result = matchSVT(mat, number_of_person, alpha=0.1, _lambda=50, threshold=0.3,
#                       dual_stochastic_SVT=False)
#
#     return result


# def match():
#     all_mat_dict = sorted(os.listdir(data_path))
#     for mat_dict in all_mat_dict:
#         mat_dict_path = data_path + '/' + mat_dict
#
#         all_mat_name = sorted(os.listdir(mat_dict_path))
#         for mat_name in all_mat_name:
#             mat_path = mat_dict_path + '/' + mat_name
#
#             # read mat
#             mat = io.loadmat(mat_path)
#             cost_mat = np.array(mat.get('Net_Cost_Mat'))
#             cost_mat = torch.from_numpy(cost_mat)
#             number_cluster = mat.get('number_cluster')[0][0]
#             number_person = np.array(mat.get('number_person'))
#             number_person = number_person.reshape((-1))
#
#             # SVN
#             SVN_result = SVT(cost_mat, number_person, pre_process = True)
#
#             # clustering
#             # clustering_result = clustering(cost_mat, number_cluster, pre_process=True)
#
#             # save result
#             out_path = save_path + '/' + mat_dict
#             make_dir(out_path)
#             print(out_path)
#             result = {
#                 'SVN_result': SVN_result,
#                 #'clustering_result': clustering_result,
#             }
#             io.savemat(out_path + '/' + mat_name, result)

def SVT(mat, number_list, this_threshold, this_alpha, this_lambda, this_mu, this_iter, with_dummy=True, pre_process=False):
    if pre_process:
        mat = torch.from_numpy(pre_processing(mat))

    # if with_dummy:
    #     mat = torch.from_numpy(add_dm_weight(mat, this_weight))

    number_of_person = [0]

    for i in range(len(number_list)):
        number_of_person.append(sum(number_list[:i + 1]))

    result = matchSVT(mat, number_of_person, alpha=this_alpha, _lambda=this_lambda, threshold=this_threshold, mu=this_mu, maxIter=this_iter,
                      dual_stochastic_SVT=False)

    return result

def match():
    threshold_list = [0.7]  # [0.65, 0.7, 0.75]
    mu_list = [50,90] #[60, 65, 70] #[64]
    _lambda_list = [60] # [40, 50, 60] # [50]
    this_weight = [0]
    this_alpha = 0
    iter_list = [75]
    start = time.perf_counter()
    for this_threshold in threshold_list:
        for this_lambda in _lambda_list:
            for this_mu in mu_list:
                this_iter = 75
                temp = 'thr=%.2f,mu=%.2f,this_lambda=%3d,iter=%3d' % (this_threshold, this_mu, this_lambda,this_iter)
                all_mat_dict = sorted(os.listdir(data_path))
                for mat_dict in all_mat_dict:
                    mat_dict_path = data_path + '/' + mat_dict

                    all_mat_name = sorted(os.listdir(mat_dict_path))
                    for mat_name in all_mat_name:
                        mat_path = mat_dict_path + '/' + mat_name

                        # read mat
                        mat = io.loadmat(mat_path)
                        cost_mat = np.array(mat.get('Net_Cost_Mat')) # Dm_Net_Cost_Mat
                        cost_mat = torch.from_numpy(cost_mat)
                        number_person = np.array(mat.get('number_person')) # number_person_dumy
                        number_person = number_person.reshape((-1))

                        # SVN
                        SVN_result = SVT(cost_mat, number_person, this_threshold, this_alpha, this_lambda, this_mu, this_iter,
                                         with_dummy=False, pre_process=False)

                        # save result
                        out_path = save_path + '/' + temp + '/' + mat_dict
                        make_dir(out_path)
                        print(out_path)
                        result = {
                            'SVN_result': SVN_result,
                        }
                        io.savemat(out_path + '/' + mat_name, result)

                os.rename(save_path + '/' + temp, save_path + '/' + temp + '_done')
    end = time.perf_counter()
    print("total time", end-start)
if __name__ == '__main__':
    # data_path = "G:\Raiser\Research\CvMHTB\CvMHATB_2022/Data_2023/Weight_mat-case"
    # save_path = "G:\Raiser\Research\CvMHTB\CvMHATB_2022/Data_2023/Solution_res_SVT-case/case5"

    # data_path = "G:\Raiser\Research\CvMHTB\CvMHATB_2021_3.5-Syn\Data_GTwoOcc\Weight_mat"
    # save_path = "G:\Raiser\Research\CvMHTB\CvMHATB_2021_3.5-Syn\Data_GTwoOcc\SSolution_res_SVT-2023-add"

    data_path = "G:\Raiser\Research\CvMHTB\CvMHATB_2021_2.0\Data\Weight_mat-final"
    save_path = "G:\Raiser\Research\CvMHTB\CvMHATB_2021_2.0\Data\Solution_res_SVT_2023-add"
    match()
