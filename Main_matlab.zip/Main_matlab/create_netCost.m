%% Compute the netCost Matrix
function net_cost = create_netCost(segment,param_netCost,view_i,param_tracklet)
scene_name = param_tracklet.sceneName;
sv_app_netCost_norm = 1;
addpath('./MOT_toolbox/');
addpath('./toolbox/');
net_cost.motion = [];
net_cost.appearance = [];
net_cost.ind = [];
offset = 1;
cnt_global = 1;

sim_cost_path = [param_tracklet.data_directory,'App_Sim/',param_tracklet.weightpath,'/'];
% svcost_path = './Data/SV_Cost/';
view_names = {'t','h1','h2','h3','h4'};
sim_cost_path = strcat(sim_cost_path, scene_name, '/');

for i=1:length(segment)
disp([view_names{view_i} 'view : sv_cost:segment-',num2str(i)]);   
    
    if isempty(segment{i})
        net_cost.ind = [net_cost.ind ; 0];
        continue;
    end

    hist1 = zeros(32*32*32,length(segment{i}.tracklet));
    curr_size = length(segment{i}.tracklet);
    for iTrack=1:length(segment{i}.tracklet)
        hist1(:,iTrack) = segment{i}.tracklet(iTrack).color_hist_median(:);
        tracklet_segment1(iTrack).frame = segment{i}.tracklet(iTrack).frame';
        tracklet_segment1(iTrack).length = length(segment{i}.tracklet(iTrack).frame);
        % ----center point coordinate ------
        tracklet_segment1(iTrack).data = [(segment{i}.tracklet(iTrack).detection(:,1)+segment{i}.tracklet(iTrack).detection(:,3))/2 ...
            (segment{i}.tracklet(iTrack).detection(:,2)+segment{i}.tracklet(iTrack).detection(:,4))/2]';
        net_cost.infoBox{cnt_global} = [segment{i}.tracklet(iTrack).frame'; ...
            segment{i}.tracklet(iTrack).origDetectionInd'; segment{i}.tracklet(iTrack).detection'];
        net_cost.infoColor{cnt_global} = [segment{i}.tracklet(iTrack).color_hist_median];
        cnt_global = cnt_global+1;
    end
   
    cnt = 1;
    for ii= i : length(segment)
        if isempty(segment{ii})
            continue;
        end
        for iTrack = 1:length(segment{ii}.tracklet)
            hist2(:,cnt) = segment{ii}.tracklet(iTrack).color_hist_median(:);
            tracklet_segment2(cnt).frame = segment{ii}.tracklet(iTrack).frame';
            tracklet_segment2(cnt).length = length(segment{ii}.tracklet(iTrack).frame);
            tracklet_segment2(cnt).data = [(segment{ii}.tracklet(iTrack).detection(:,1)+segment{ii}.tracklet(iTrack).detection(:,3))/2 ...
                (segment{ii}.tracklet(iTrack).detection(:,2)+segment{ii}.tracklet(iTrack).detection(:,4))/2]';
            cnt = cnt+1;
        end
    end
    
    cnt_next = 1;
    tracklet_segment3 = [];
    if i < length(segment)
    for i_next = i + 1 
        if isempty(segment{i_next})
            continue;
        end
        for iTrack = 1:length(segment{i_next}.tracklet)
            hist3(:,cnt_next) = segment{i_next}.tracklet(iTrack).color_hist_median(:);
            tracklet_segment3(cnt_next).frame = segment{i_next}.tracklet(iTrack).frame';
            tracklet_segment3(cnt_next).length = length(segment{i_next}.tracklet(iTrack).frame);
            tracklet_segment3(cnt_next).data = [(segment{i_next}.tracklet(iTrack).detection(:,1)+segment{i_next}.tracklet(iTrack).detection(:,3))/2 ...
                (segment{i_next}.tracklet(iTrack).detection(:,2)+segment{i_next}.tracklet(iTrack).detection(:,4))/2]';
            cnt_next = cnt_next+1;
        end
    end
    end
    
    if i==1
        net_cost.appearance=zeros(size(tracklet_segment2,2));
        net_cost.motion = zeros(size(tracklet_segment2,2));
    end

    %% Compute Motion Sim
    if isempty(tracklet_segment3)
        N = 0;
        S = [];
    else
        if i < length(segment)
            N = length(tracklet_segment3); % tracklet_segment3 : next tracklets of the video
            M = length(tracklet_segment1); % tracklet_segment1 : The tracklets of the i-th segment
            S = zeros(M,N);
            for iii=1:M
                for jjj=1:N
                    S(iii,jjj) = compute_motion_cost_constVel(tracklet_segment1(iii),tracklet_segment3(jjj),param_netCost);
                end
            end   
        else
            S(1:curr_size,1:curr_size) = NaN;
        end
    end
    % S12 = S';
    
    %% Compute Appearance Sim
    if  i < length(segment) && view_i >= 2
        
        sim_data = fullfile(sim_cost_path,['seg_' num2str(i+1,'%03d') '/svSim.mat']);
        if exist(sim_data,'file')==0
            cross_time_sim = {[]};
        else
            cross_time_sim = struct2cell(load(sim_data));
        end
        
        try
        cross_time_sim = cross_time_sim{1};
        

        if length(cross_time_sim) < view_i-1
            cross_time_sim{view_i-1} = [];
        end
        app_sim = cross_time_sim{view_i-1};
        
        catch err
        end
        [last_size,sec_size] = size(app_sim);
        if curr_size ~= last_size
           sec_size
        end
        
        app_sim_score = 1 - app_sim;
        
        if param_netCost.sv_app_netCost_norm == 1 && ~isempty(app_sim)
            app_sim_score = normalizing(app_sim_score,0,1);
           %% only preserve the maximum
            [max_a,index]=max(app_sim_score,[],2);
            temp = zeros(size(app_sim_score));
            for row = 1 : size(app_sim_score,1)
                temp(row,index(row)) = max_a(row);
            end
            app_sim_score = temp;
        end
        
        
%       hi_dist = slmetric_pw(hist1,hist2,'intersect');
%       hi_dist(1:curr_size,1:curr_size)=NaN;
%       net_cost.appearance(offset:offset+curr_size-1,offset:end) = 2*hi_dist;
        net_cost.appearance(offset:offset+curr_size-1,offset:offset+curr_size-1) = NaN;
        try
        net_cost.appearance(offset:offset+curr_size-1,offset + curr_size :offset + curr_size + sec_size -1) = app_sim_score ;
        catch err
        end

        if sec_size ~= N
            N
        end
        
    end
    
    if  i < length(segment)
        try
        net_cost.motion(offset:offset+curr_size-1,offset + curr_size :offset + curr_size + N -1) = 2 * S;
        catch err
        end
    end
        
   
%     if view_i == 1
%         hi_dist = slmetric_pw(hist1,hist2,'intersect');
%         hi_dist(1:curr_size,1:curr_size)=NaN;
%         net_cost.appearance(offset:offset+curr_size-1,offset:end) = 2*hi_dist;
%     end
    
    % net_cost.motion(offset:offset+curr_size-1,offset:end) =  2*S;
    net_cost.ind = [net_cost.ind ; curr_size];
    offset = offset+curr_size;
    clear hi_dist hist2 hist1 S tracklet_segment1 tracklet_segment2 tracklet_segment3;
    
end
