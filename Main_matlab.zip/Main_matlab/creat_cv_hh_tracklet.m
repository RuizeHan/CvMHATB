function creat_cv_hh_tracklet(data,param_tracklet,save_tracklet)

num_hor_seq = data.num_hor_seq;
tv_setments = data.cv_segments{1,1};

for hor_i = 2 : num_hor_seq+1

hv_segments = data.cv_segments{hor_i,1};

if save_tracklet == 1
    for seg_i = 1 : length(hv_segments)
    % Save the tracklets of two views
        frame_range = (seg_i-1) * param_tracklet.num_frames + 1 : seg_i * param_tracklet.num_frames;
        data.frame_range = frame_range;   
        try
        hv_segment_i = hv_segments{1,seg_i};
        catch err
        end
        path = [param_tracklet.data_directory, 'Tracklets_img-YoloV6/',param_tracklet.weightpath,'/' param_tracklet.sceneName, '/'];
        savepath = strcat(path,'seg_',num2str(seg_i,'%03d'));
        if(~exist(savepath,'dir'))
            mkdir(savepath);
        end
        if isempty(hv_segment_i)
            continue
        end
        hv_tracklets = hv_segment_i.tracklet;
        tracklets = {hv_tracklets};
        views = {'t','h1','h2','h3','h4'};

            sv_tracklet = tracklets{1};
            images = data.cv_images{hor_i};

            for tra_i = 1 : length(sv_tracklet)
            tracklet =  sv_tracklet(tra_i);
            frames = tracklet.frame;
            detection = tracklet.detection;
    %       sum_det = 0;

            % save all the frames in the tracklet
    %         for frm_i = 1 : length(frames)
    %             frm = frames(frm_i);
    %             image = images(frm);
    %             img = imread([image.folder,'/',image.name]);
    %             reg = detection(frm_i,:);
    %             det = imcrop(img,[reg(1),reg(2),reg(3)-reg(1),reg(4)-reg(2)]);
    % %           imshow(det);
    %             imwrite(det,strcat(savepath,'/',views{hor_i},'_tra_',num2str(tra_i),'_fri_',num2str(frm_i),'.jpg'));
    % %           det = imresize(det,[100,100]);
    % %           sum_det = double(det) + sum_det;       
    %         end
            % save the middle frame in the tracklet
            for frm_i = floor((1 + length(frames)/2))
                frm = frames(frm_i);
                image = images(frm);
                img = imread([image.folder,'/',image.name]);
                reg = detection(frm_i,:);
                det = imcrop(img,[reg(1),reg(2),reg(3)-reg(1),reg(4)-reg(2)]);
                imwrite(det,strcat(savepath,'/',views{hor_i},'_tra_',num2str(tra_i),'.jpg'));
            end
            % save the mean image in the tracklet
    %         avg_det = uint8(sum_det/frm_i);
    %         imshow(avg_det);
    %         imwrite(avg_det,strcat(savepath,'/',views{view_i},'_tra_',num2str(tra_i),'.jpg'));
            end
        end

    end

end

end