function nodes = GMMCP_Tracklet_Generation_SVN(sv_net_cost,num_hor_seq, firstSeg, lastSeg,param_tracklet)

%  calculate the Cost Mat of a single view between two segment

% appearanceWeight = params.sv_appearanceWeight;
% motionWeight = 1 - appearanceWeight;
% dummyWeight = params.dummyWeight;
% forceExtraCliques = 1;

% save_weight = 1;
use_cluster = 0;
clster_new = 1;

num_all_view = num_hor_seq + 1;
cv_NN = zeros(1 + num_hor_seq,lastSeg-firstSeg+1);

    for view_i = 1 : num_all_view

        net_cost = sv_net_cost{view_i};
        NN = net_cost.ind;  %The number of tracklets in each segment

        % sometimes there is no tracklet at the end of the video and sizes don't
        % match up so we need to do a check here
        if lastSeg>size(NN,1)
            lastSeg=size(NN,1);
        end

        NN = NN(firstSeg:lastSeg);
        cv_NN(view_i,:) = NN;

    end

NN = cv_NN(:);  %top 1 and 2
number_cluster = max(cv_NN(:));

% old
%     clusterpath = [param_tracklet.data_directory 'Cluster_Res_new_gen/', param_tracklet.sceneName, '/'];
%     Clu = struct2cell(load([clusterpath,'seg_',num2str(firstSeg),'.mat']));
%     Clu_old = Clu{2}+1;
    
% new
    weight_matrix_path = param_tracklet.weightpath; %'Sol_Weight_mat_new_gen_new_SVN/'
    
%     savepath = [param_tracklet.data_directory 'Solution_res_SVT-case/'];
%     
%     dirOutput=dir(fullfile(savepath));
%     
%     for i =  3 : length(dirOutput)
%     
%     paraname = dirOutput(i).name;
       
    clusterpath = [param_tracklet.data_directory 'Solution_res_SVT-case/case5/' weight_matrix_path '/' param_tracklet.sceneName, '/'];
    Res = (load([clusterpath,'seg_',num2str(firstSeg),'.mat']));
    
%     end

    %cv_NN = cv_NN+1;
    
    if use_cluster == 1 
        if clster_new == 1
            Res_mat = Res.self_tuning_clustering_result;
        else
            Res_mat = Res.clustering_result;
        end
    else
        Res_mat = Res.SVN_result;
    end
    
    Clu = zeros(1,sum(cv_NN(:)));
    idx_all = zeros(length(Res_mat),4);
    c = 0;
    for i = 1 : length(Res_mat)
        idx = find(Res_mat(i,:) == 1);
        idx_all(i,1:length(idx)) = idx;
        try
        if sum(Clu(idx)) == 0
        Clu(idx) = c;
        c = c + 1;
        end
        catch err 
        end   
    end

    Clu = Clu';  %  Clu_old or Clu
    Clu_idx = 1 : length(Clu);
    clu_mat = zeros(number_cluster, num_all_view *2);
    
    for clu_i = 1 : number_cluster
        try
        Clu_block = mat2cell(Clu,cv_NN(:));
        catch err
        end
        Idx_block = mat2cell(Clu_idx',cv_NN(:));
        for view_i = 1 : num_all_view *2
            Clu_block_i = Clu_block{view_i};
            Idx_block_i = Idx_block{view_i};
            idx = Idx_block_i(Clu_block_i == clu_i);
            if ~isempty(idx)
                clu_mat(clu_i,view_i) = idx(1);  % todo: filter the repetitive idx by the similarity
            end
        end
    end

    clu_res = clu_mat;
    clu_res = sortrows(clu_res,1);
    % add the dummy node
    clu_res(clu_res(:) == 0) = -10;
    NN_original = NN;
    NN_dumy = NN_original + 1;
    cum_NN = cumsum(NN_dumy);
    for view_i = 1 : num_all_view *2
    
    % comment this line when using dummy_node_weight
    clu_res(:,view_i) = clu_res(:,view_i) + view_i - 1;
    
    clu_res(clu_res(:,view_i)<0,view_i) = cum_NN(view_i);  
    end

    nodes = clu_res;

% % save(fullfile(savePath,sprintf('segment_%03d_to_%03d.mat',firstSeg, lastSeg)),'Net_Cost_Mat','Net_Cost_Mat_Original','NN_original','dummy_counts','dummyWeight','NN','NC','nodes','cost','Kcliques','timeSpent');
% fprintf('cost: %d, time: %d\n', cost, timeSpent);

end