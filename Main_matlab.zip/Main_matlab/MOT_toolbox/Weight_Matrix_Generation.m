function [NN_dumy,NN_original] = Weight_Matrix_Generation(sv_net_cost,cv_net_cost,cv_hh_net_cost,num_hor_seq, firstSeg, lastSeg, params,param_tracklet)

%  calculate the Cost Mat of a single view between two segment

appearanceWeight = params.sv_appearanceWeight;
motionWeight = 1 - appearanceWeight;
% dummyWeight = params.dummyWeight;

dummyWeight = -1;  % a temp value for dummy weight

forceExtraCliques = 1;

save_weight = 1;
use_cluster= 0;

num_all_view = num_hor_seq + 1;

sv_Net_Cost_Mat = cell(1 + num_hor_seq,1);
NC = (1 + num_hor_seq) * 2;
cv_NN = zeros(1 + num_hor_seq,lastSeg-firstSeg+1);

for view_i = 1 : num_all_view

    net_cost = sv_net_cost{view_i};
    net_cost.motion = (net_cost.motion + net_cost.motion')/2;
    try
    net_cost.appearance = (net_cost.appearance + net_cost.appearance')/2;
    catch err
    end
    
    if view_i > 1
        Net_Cost_Mat = appearanceWeight*net_cost.appearance + motionWeight*net_cost.motion;
        Net_Cost_Mat1 = 0.3*net_cost.appearance + 0.7*net_cost.motion;
    else 
        Net_Cost_Mat = net_cost.motion;  % We only use the motion feature for top view
    end

    NN = net_cost.ind;  %The number of tracklets in each segment
    
    % sometimes there is no tracklet at the end of the video and sizes don't
    % match up so we need to do a check here
    if lastSeg>size(NN,1)
        lastSeg=size(NN,1);
    end

    Net_Cost_Mat = Net_Cost_Mat(sum(NN(1:(firstSeg-1)))+1:sum(NN(1:lastSeg)),sum(NN(1:(firstSeg-1)))+1:sum(NN(1:lastSeg)));
    if view_i > 1
    Net_Cost_Mat1 = Net_Cost_Mat1(sum(NN(1:(firstSeg-1)))+1:sum(NN(1:lastSeg)),sum(NN(1:(firstSeg-1)))+1:sum(NN(1:lastSeg)));
    end
    % motionCost = net_cost.motion(sum(NN(1:(firstSeg-1)))+1:sum(NN(1:lastSeg)),sum(NN(1:(firstSeg-1)))+1:sum(NN(1:lastSeg)));
    % appCost = net_cost.appearance(sum(NN(1:(firstSeg-1)))+1:sum(NN(1:lastSeg)),sum(NN(1:(firstSeg-1)))+1:sum(NN(1:lastSeg)));
    
    NN = NN(firstSeg:lastSeg);
    cv_NN(view_i,:) = NN;

    Net_Cost_Mat_Original = Net_Cost_Mat;
    
    if params.sv_netCost_norm && ~isempty(Net_Cost_Mat)
        Net_Cost_Mat = normalizing(Net_Cost_Mat,0,1);
    end

    sv_Net_Cost_Mat{view_i} = Net_Cost_Mat(1:NN(1),NN(1)+1:NN(1) + NN(2));

end

NN_ori = [cv_NN(1),cv_NN(3),cv_NN(4),cv_NN(2)];

tv_Net_Cost_Mat = sv_Net_Cost_Mat{1};
hv_Net_Cost_Mat = sv_Net_Cost_Mat{2};

% calculate the Cost Mat in the same segment between two views
cv_Net_Cost_Mat = cell(2,1);


for time_i = firstSeg : lastSeg

    th_Cost = cv_net_cost(time_i,:);

    cv_th_Cost_Mat{time_i - firstSeg + 1} = th_Cost;

    if num_hor_seq > 1
        try
        hh_Cost = cv_hh_net_cost(time_i,:);
        catch err
        end
        if params.cvhh_netCost_norm 
            try
            for i = 1 : length(hh_Cost)
                if ~isempty(hh_Cost{i})
                hh_Cost{i} = normalizing(hh_Cost{i},0,1);
                end
            end
            catch err
            end
        end
    else
        hh_Cost = [];
    end
    cv_hh_Cost_Mat{time_i - firstSeg + 1} = hh_Cost;
    
end


cv0_th_Cost_Mat = cv_th_Cost_Mat{1};
cv0_hh_Cost_Mat = cv_hh_Cost_Mat{1};
cv1_th_Cost_Mat = cv_th_Cost_Mat{2};
cv1_hh_Cost_Mat = cv_hh_Cost_Mat{2};

NN = zeros(NC,1);
NN = cv_NN(:);  %top 1 and 2

% NN_original = NN;
dummy_counts = ones(size(NN));
% Kcliques = max(NN(:)) + forceExtraCliques;

% the matrix for all the cost
Net_Cost_Mat = zeros(sum(NN),sum(NN))*nan;


sv_Net_Cost_01 = blkdiag(sv_Net_Cost_Mat{:});
Net_Cost_Mat(1:sum(cv_NN(:,1)),sum(cv_NN(:,1))+1:end) = sv_Net_Cost_01;
Net_Cost_Mat(sum(cv_NN(:,1))+1:end,1:sum(cv_NN(:,1))) = sv_Net_Cost_01';

nanMat0 = [];
nanMat1 = [];
for i = 1 : num_hor_seq + 1
aa = zeros(cv_NN(i,1))*nan; 
bb = zeros(cv_NN(i,2))*nan;
%zeros(cv_NN(2,1))*nan,zeros(cv_NN(3,1))*nan,zeros(cv_NN(4,1))*nan];
nanMat0 = blkdiag(nanMat0,aa);
nanMat1 = blkdiag(nanMat1,bb);
end

% = blkdiag(,zeros(cv_NN(2,2))*nan,zeros(cv_NN(3,2))*nan,zeros(cv_NN(4,2))*nan);


for time = 1 : 2
    if time == 1
        cv_th_Cost_Mat = cv0_th_Cost_Mat;
        cv_hh_Cost_Mat = cv0_hh_Cost_Mat;
        nanMat = nanMat0;
        NN_view = cv_NN(:,1);
    else
        cv_th_Cost_Mat = cv1_th_Cost_Mat;
        cv_hh_Cost_Mat = cv1_hh_Cost_Mat;
        nanMat = nanMat1;
        NN_view = cv_NN(:,2);
    end
    
    % cross top-hor view cost
    cv_th_Cost_Mat_con = [];
    for i = 1 : length(cv_th_Cost_Mat)
        cv_th_Cost_Mat_con = [cv_th_Cost_Mat_con,cv_th_Cost_Mat{i}];
    end
    try
    if ~isempty(cv_th_Cost_Mat_con)
        nanMat(1: NN_view(1), NN_view(1)+1:end) = cv_th_Cost_Mat_con;
    end
    catch err
    end
    
    blok = 1;
    
    for j = 2 : length(NN_view) - 1
        
        for k = j + 1 : length(NN_view)    
            cum_NN = cumsum(NN_view);    
            try
            nanMat(cum_NN(j-1)+1:cum_NN(j),cum_NN(k-1)+1:cum_NN(k)) = cv_hh_Cost_Mat{blok};
            catch err
            end
            blok = blok + 1;
        end
        
    end
    
    if time == 1
        Net_Cost_Mat(1:sum(NN_view),1:sum(NN_view)) = nanMat + nanMat';
    else
        Net_Cost_Mat(end-sum(NN_view)+1:end,end-sum(NN_view)+1:end) = nanMat + nanMat';
    end
    
end

Net_Cost_Mat(isnan(Net_Cost_Mat)) = 0;

% C1 : set the diag value into 0 and other values into 0.1
% Net_Cost_Mat(Net_Cost_Mat==0) = 0.1;

% C2 : set the diag value into 0 and other values by the related values
% Step 1 : the top view and the hor view(s) in another clip

Net_Cost_Mat_blok = mat2cell(Net_Cost_Mat,NN,NN);

% T -> H1' H2' H3'
mat_THx = cell(num_hor_seq,2);
% T -> T'(Tx)
mat_TTx = Net_Cost_Mat_blok{1, num_all_view + 1};

for hi = 1 : num_hor_seq
    mat_TxHx = Net_Cost_Mat_blok{num_all_view + 1, num_all_view + 1 + hi};
    mat_THx{hi,1} = mat_TTx * mat_TxHx;
    mat_THx{hi,2} = (mat_TTx * mat_TxHx)';
    Net_Cost_Mat_blok(1,num_all_view + 1 + hi) = mat_THx(hi,1);
    Net_Cost_Mat_blok(num_all_view + 1 + hi,1) = mat_THx(hi,2);
end

% T' -> H1 H2 H3
mat_TxT = Net_Cost_Mat_blok{num_all_view + 1, 1};
mat_TxH = cell(num_hor_seq,1);
for hi = 1 : num_hor_seq
    mat_TH = Net_Cost_Mat_blok{1, 1 + hi};
    mat_TxH{hi,1} = mat_TxT * mat_TH;
    mat_TxH{hi,2} = (mat_TxT * mat_TH)';
    Net_Cost_Mat_blok(num_all_view + 1, 1 + hi) = mat_TxH(hi,1);
    Net_Cost_Mat_blok(1 + hi, num_all_view + 1) = mat_TxH(hi,2);
end

% Step 2 : the hor view and the hor view(s) in another clip

hor_idx = 1 : num_hor_seq;

for hi = hor_idx
    % target row : hi + 1 ; target col : except hi
    for hj =  setdiff(hor_idx, hi)
        
        % H1 -> H2 -> H2'(H2x)
        H1H2 = Net_Cost_Mat_blok{hi + 1 , hj + 1};
        H2H2x = Net_Cost_Mat_blok{hj + 1, num_all_view + hj + 1};
        H1H2x = H1H2 * H2H2x;
        
        % H1 -> H1' -> H2'
        H1H1x = Net_Cost_Mat_blok{hi+1, num_all_view + hi+1};
        H1xH2x = Net_Cost_Mat_blok{ num_all_view + hi+1, num_all_view + hj + 1};
        H1H2x_mir = H1H1x * H1xH2x;
        
        Net_Cost_Mat_blok{hi + 1, num_all_view + hj + 1} = (H1H2x + H1H2x_mir)/2;
        Net_Cost_Mat_blok{num_all_view + hj + 1, hi + 1} = (H1H2x' + H1H2x_mir')/2;
    end
end

Net_Cost_Mat = cell2mat(Net_Cost_Mat_blok);
Net_Cost_Mat(logical(eye(size(Net_Cost_Mat))))= ones(size(Net_Cost_Mat,1),1);
NN_original = NN;

[Dm_Net_Cost_Mat, NN_dumy, detectionInds, dummyInds] = addDummyNodes_v03(Net_Cost_Mat, NN, dummy_counts, dummyWeight);

Dm_Net_Cost_Mat(isnan(Dm_Net_Cost_Mat)==1) = dummyWeight;   % change the NaN in to the temp value 'dummyWeight' for dummy nodes

number_cluster = max(cv_NN(:));
number_person = NN;
number_person_dumy = NN + ones(size(NN));

NN_dumy = NN_original + 1;


% Net_Cost_Mat((Net_Cost_Mat)<=0) = -10;
% sigma = 0.1;
% for i = 1 : 5
%     
% Clu = spectral(Net_Cost_Mat,sigma,number_cluster);
% [Clu{i}, L, U] = SpectralClustering(Net_Cost_Mat, number_cluster ,3);
% 
% end

if save_weight ==1
    savepath = [param_tracklet.data_directory 'Weight_mat-case/',param_tracklet.sceneName, '/'];
    if(~exist(savepath,'dir'))
        mkdir(savepath);
    end
    save([savepath,'seg_',num2str(firstSeg),'.mat'],'Net_Cost_Mat','Dm_Net_Cost_Mat','number_cluster','number_person','number_person_dumy');
end

%     if use_cluster == 1
% 
%     clusterpath = [param_tracklet.data_directory '/Cluster_Res/', param_tracklet.sceneName, '/'];
%     Clu = struct2cell(load([clusterpath,'clusting_seg',num2str(firstSeg),'.mat']));
%     Clu = Clu{1};
%     Clu = Clu'+1;
%     Clu_idx = 1 : length(Clu);
%     clu_mat = zeros(number_cluster, num_all_view *2);
%     for clu_i = 1 : number_cluster
%         Clu_block = mat2cell(Clu,cv_NN(:));
%         Idx_block = mat2cell(Clu_idx',cv_NN(:));
%         for view_i = 1 : num_all_view *2
%             Clu_block_i = Clu_block{view_i};
%             Idx_block_i = Idx_block{view_i};
%             idx = Idx_block_i(Clu_block_i == clu_i);
%             if ~isempty(idx)
%                 clu_mat(clu_i,view_i) = idx(1);  % todo: filter the repetitive idx by the similarity
%             end
%         end
%     end
% 
% 
%     clu_res = clu_mat;
%     clu_res = sortrows(clu_res,1);
%      % add the dummy node
%     clu_res(clu_res(:) == 0) = -10;
%     NN_original = NN;
%     NN = NN_original + 1;
%     cum_NN = cumsum(NN);
%     for view_i = 1 : num_all_view *2
%     clu_res(:,view_i) = clu_res(:,view_i) + view_i - 1;
%     clu_res(clu_res(:,view_i)<0,view_i) = cum_NN(view_i);  
%     % clu_res(clu_res(:,2)<0,2) = NN(1)+NN(2);  
%     % clu_res(clu_res(:,3)<0,3) = NN(1)+NN(2)+NN(3);  
%     % clu_res(clu_res(:,4)<0,4) = NN(1)+NN(2)+NN(3)+NN(4);  
%     end
% 
%     nodes = clu_res;
% 
%     end

% % save(fullfile(savePath,sprintf('segment_%03d_to_%03d.mat',firstSeg, lastSeg)),'Net_Cost_Mat','Net_Cost_Mat_Original','NN_original','dummy_counts','dummyWeight','NN','NC','nodes','cost','Kcliques','timeSpent');
% fprintf('cost: %d, time: %d\n', cost, timeSpent);

end