function nodes = GMMCP_Tracklet_Generation(sv_net_cost,num_hor_seq, firstSeg, lastSeg,param_tracklet)

%  calculate the Cost Mat of a single view between two segment

% appearanceWeight = params.sv_appearanceWeight;
% motionWeight = 1 - appearanceWeight;
% dummyWeight = params.dummyWeight;
% forceExtraCliques = 1;

% save_weight = 1;
use_cluster = 1;
num_all_view = num_hor_seq + 1;
cv_NN = zeros(1 + num_hor_seq,lastSeg-firstSeg+1);

for view_i = 1 : num_all_view

    net_cost = sv_net_cost{view_i};
    NN = net_cost.ind;  %The number of tracklets in each segment
    
    % sometimes there is no tracklet at the end of the video and sizes don't
    % match up so we need to do a check here
    if lastSeg>size(NN,1)
        lastSeg=size(NN,1);
    end
   
    NN = NN(firstSeg:lastSeg);
    cv_NN(view_i,:) = NN;

end

NN = cv_NN(:);  %top 1 and 2
number_cluster = max(cv_NN(:));

if use_cluster == 1

    clusterpath = [param_tracklet.data_directory 'Cluster_Res/', param_tracklet.sceneName, '/'];
    Clu = struct2cell(load([clusterpath,'clustering_seg',num2str(firstSeg),'.mat']));
    Clu = Clu{1};
    Clu = Clu'+1;
    Clu_idx = 1 : length(Clu);
    clu_mat = zeros(number_cluster, num_all_view *2);
    for clu_i = 1 : number_cluster
        Clu_block = mat2cell(Clu,cv_NN(:));
        Idx_block = mat2cell(Clu_idx',cv_NN(:));
        for view_i = 1 : num_all_view *2
            Clu_block_i = Clu_block{view_i};
            Idx_block_i = Idx_block{view_i};
            idx = Idx_block_i(Clu_block_i == clu_i);
            if ~isempty(idx)
                clu_mat(clu_i,view_i) = idx(1);  % todo: filter the repetitive idx by the similarity
            end
        end
    end

    clu_res = clu_mat;
    clu_res = sortrows(clu_res,1);
     % add the dummy node
    clu_res(clu_res(:) == 0) = -10;
    NN_original = NN;
    NN_dumy = NN_original + 1;
    cum_NN = cumsum(NN_dumy);
    for view_i = 1 : num_all_view *2
    clu_res(:,view_i) = clu_res(:,view_i) + view_i - 1;
    clu_res(clu_res(:,view_i)<0,view_i) = cum_NN(view_i);  
    % clu_res(clu_res(:,2)<0,2) = NN(1)+NN(2);  
    % clu_res(clu_res(:,3)<0,3) = NN(1)+NN(2)+NN(3);  
    % clu_res(clu_res(:,4)<0,4) = NN(1)+NN(2)+NN(3)+NN(4);  
    end

    nodes = clu_res;

end

% % save(fullfile(savePath,sprintf('segment_%03d_to_%03d.mat',firstSeg, lastSeg)),'Net_Cost_Mat','Net_Cost_Mat_Original','NN_original','dummy_counts','dummyWeight','NN','NC','nodes','cost','Kcliques','timeSpent');
% fprintf('cost: %d, time: %d\n', cost, timeSpent);

end