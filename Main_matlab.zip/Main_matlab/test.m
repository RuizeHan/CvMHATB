figure
plot(1:10)
x = [.1 1];
y = [.1 1];
annotation('textarrow',x,y,'String','y = x ')