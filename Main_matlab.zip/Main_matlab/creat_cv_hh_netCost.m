function cv_net_cost =  creat_cv_hh_netCost(data,param_tracklet)

num_hor_seq = data.num_hor_seq;
tv_setments = data.cv_segments{1,1};

for hor_i = 2 : num_hor_seq+1

hv_segments = data.cv_segments{hor_i,1};
    
if num_hor_seq > 1   
    cv_net_cost = cell(length(tv_setments),nchoosek(num_hor_seq,2));
    %-----------------------------read the app cost----------------------------
    for seg_i = 1 : length(tv_setments)
        disp(['chhv_cost:segment-',num2str(seg_i)]);
        app_path = [param_tracklet.data_directory, 'App_Sim/',param_tracklet.weightpath,'/', param_tracklet.sceneName];
        
        sim_data = fullfile(app_path, ['seg_' num2str(seg_i,'%03d') '/cvSim.mat']);
        if exist(sim_data,'file')==0
            Sim_App_seg_i = {[]};
        else
            Sim_App_seg_i = struct2cell(load(sim_data));
        end

        tracklets_dis_App = Sim_App_seg_i{1};
        
        if length(tracklets_dis_App) < nchoosek(num_hor_seq,2)   
            cv_net_cost = [];
        else
        for j = 1 : nchoosek(num_hor_seq,2)
            try
            cv_net_cost{seg_i,j} = 1 - tracklets_dis_App{j};   % transform the distance into similarity
            catch err
            end
        end
        end
        
    end
    
else
    cv_net_cost = [];
end

end

end